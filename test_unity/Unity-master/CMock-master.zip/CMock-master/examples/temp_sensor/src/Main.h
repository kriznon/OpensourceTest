#ifndef _MAIN_H_
#define _MAIN_H_

int AppMain(void);
int main(void);

#endif // _MAIN_H_
